def callme():
  return("Hi i am whirldata, How can i help you")